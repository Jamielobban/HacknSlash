using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackHolder : MonoBehaviour
{
    public List<BaseAttack> attacks = new List<BaseAttack>();

}
